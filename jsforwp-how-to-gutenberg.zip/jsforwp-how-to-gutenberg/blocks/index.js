/**
 * Import internationalization
 */
import './i18n.js';

/**
 * Import registerBlockType blocks
 */
import './register-block-type/';
import './demo/';
