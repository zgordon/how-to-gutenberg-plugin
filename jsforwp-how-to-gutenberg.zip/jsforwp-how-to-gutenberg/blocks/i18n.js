wp.i18n.setLocaleData( { '': {} }, 'jsforwphowto' );
